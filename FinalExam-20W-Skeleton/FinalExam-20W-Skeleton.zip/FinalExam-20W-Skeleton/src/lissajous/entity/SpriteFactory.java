package lissajous.entity;

public class SpriteFactory {
	
	private SpriteFactory() {
		
	}
	public <T>T getSprite(String name) {
		if (name==null ) {
			throw new(NullPointerException e);
		}
		
		if( name =="tracing" ) {
			 TracingCurveSprite tracing = new TracingCurveSprite();
		}else if(name == "shifting" ) {
			 ShiftingCurveSprite shifting = new ShiftingCurveSprite();
		}else {
			throw (UnsupportedOperationException e );			
		}	
		
		return (T)name;
	}
	}


