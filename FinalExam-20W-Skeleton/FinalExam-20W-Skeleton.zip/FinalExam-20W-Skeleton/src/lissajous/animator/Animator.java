package lissajous.animator;

import java.util.function.Consumer;

import com.sun.prism.paint.Color;

import javafx.scene.canvas.GraphicsContext;
import sidescroller.entity.property.Entity;

public class Animator extends AbstractAnimator{
	
	private Color background  = Color.ANTIQUEWHITE;
	private  long lastTime;
	
	@Override
	public void handle(GraphicsContext gc, long now) {
		if(now-lastTime>1000000000/3 ) {
			lastTime=now;
            
			 clearAndFill( gc, background);
			 drawEntities(gc);
			
		}
		}
	
		
	

	public void drawEntities(GraphicsContext graphicsContext) {
		 BiConsumer<Entity,GraphicsContext> draw = (e) ->{  
			 if(e!=null && e.isDrawable()){
				 entity.getDrawable().draw(gc);
			 }		 
		 };	 
        draw. accept( map.getBackground(), graphicsContext);	
        
        for (lissajous.entity.property.Entity e : map.entities()) {
        	draw. accept( e, graphicsContext);
        }
	}
	}

	
	

	

