package lissajous.scene;

import com.sun.prism.paint.Color;

public class CurveBuilder {
	private int a;
	private int b;
	private double xShift;
	private double yShift;
	private double width;
	private double radius ;
	private double increment;
	private double phaseShift;
	private  Color color;
	private  String spriteName;

	private  static final CurveBuilder BUILDER =   new CurveBuilder() ;
	
	private CurveBuilder() {
	}
	
	public CurveBuilder instance(){
		
	}
	
	public CurveBuilder setRadiusValue(double radius) {
		this.radius = radius;
		return this;
	}
	
	public CurveBuilder  setStepIncrement(double increment) {
		this.increment =increment;
		return this;
	}
	
	public CurveBuilder setPhaseShiftInDegrees( double phaseShift) {	
		this. phaseShift = phaseShift;
		return this;
	}
	
	public CurveBuilder setStroke(Color color, int width) {
		this.color = color ;
		this.width = width ;
		return this;
	}
	
	public CurveBuilder setPosition(double xShift, double yShift) {
		this.xShift =  xShift ;
		this.yShift =  yShift ;
		return this;
	}

	public CurveBuilder setABRatio(int a,  int b) {
		this.a =  a ;
		this.b=  b ;
		return this;
	}
	
	public CurveBuilder  setSpriteName(String name) {
		this.spriteName= name  ;
		return this;
	}
	
	public GenericEntity build() {
		 AbstractCurveSprite  sprite = spriteFactory.getSprite(spriteName);
		 sprite. setFill( Color.TRANSPARENT);
		 sprite. setStroke( color);
		 sprite. setWidth(width); 
		 sprite. setRadiusValue( radius);
		 sprite.setRadiusValue( radius); 
		 sprite.setStepIncrement(increment);
		 sprite. setPhaseShiftInDegrees(phaseShift);
		 sprite.setPosition(xShift, yShift);
		 sprite. setABRatio(a,b);
		 GenericEntity entity = new GenericEntity(sprite);
		 
		 return entity;
	}
	}

	
	

