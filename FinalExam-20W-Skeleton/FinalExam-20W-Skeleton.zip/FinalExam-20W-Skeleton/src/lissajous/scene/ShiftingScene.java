package lissajous.scene;

public class ShiftingScene {
	public ShiftingScene  createScene() {
		 CurveBuilder cb = cb.isntance();
		 cb. setStroke( Color.BLACK, 1);
		 cb. setRadiusValue(100);
		 cb.  setStepIncrement(2);
		 cb. setPhaseShiftInDegrees(90);
		 cb. setSpriteName( "shifting");
		 
		 for( i < 4) {
			 for( j< 4) {
			cb. setPosition( i*200-50, j*200-75);	 
			 cb.setABRatio( i,  j);
			GenericEntity  entity = cb. build();
			cb.add(entity);
			 }			 	 
		return this;
	}
	
	}
}


