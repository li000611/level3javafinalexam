package lissajous.scene;

public class TracingScene {
	
	public   TracingScene  createScene() {
		 CurveBuilder cb = cb.isntance();
		 cb. setStroke( Color.BLACK, 1);
		 cb. setRadiusValue(50);
		 cb.  setStepIncrement(2);
		 cb. setPhaseShiftInDegrees(90);
		 cb. setSpriteName( "tracing");
		 
		 for( i < 7) {
			 for( j< 7) {
			cb. setPosition( i*100, j*100-25);	 
			 cb.setABRatio( i,  j);
			GenericEntity  entity = cb. build();
			cb.add(entity);
			 }			 	 
		return this;
	
	}

	}
}
